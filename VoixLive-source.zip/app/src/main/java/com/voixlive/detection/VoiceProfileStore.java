package com.voixlive.detection;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

final class VoiceProfileStore {
    private static final String PREFS = "voice_profile_v2";
    private static final String DATA = "vectors";
    private static final String THRESHOLD = "threshold";

    private final SharedPreferences prefs;

    VoiceProfileStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    void save(List<float[]> vectors, float threshold) {
        int count = vectors.size();
        ByteBuffer buffer = ByteBuffer.allocate(8 + count * MfccExtractor.FEATURE_SIZE * 4)
                .order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(count);
        buffer.putInt(MfccExtractor.FEATURE_SIZE);
        for (float[] vector : vectors) {
            for (float value : vector) buffer.putFloat(value);
        }
        prefs.edit()
                .putString(DATA, Base64.encodeToString(buffer.array(), Base64.NO_WRAP))
                .putFloat(THRESHOLD, threshold)
                .apply();
    }

    List<float[]> load() {
        List<float[]> result = new ArrayList<>();
        String encoded = prefs.getString(DATA, null);
        if (encoded == null) return result;
        try {
            ByteBuffer buffer = ByteBuffer.wrap(Base64.decode(encoded, Base64.NO_WRAP))
                    .order(ByteOrder.LITTLE_ENDIAN);
            int count = buffer.getInt();
            int size = buffer.getInt();
            if (count < 1 || count > 100 || size != MfccExtractor.FEATURE_SIZE) return result;
            for (int i = 0; i < count; i++) {
                float[] vector = new float[size];
                for (int j = 0; j < size; j++) vector[j] = buffer.getFloat();
                result.add(vector);
            }
        } catch (Exception ignored) {
            result.clear();
        }
        return result;
    }

    float threshold() { return prefs.getFloat(THRESHOLD, 0.88f); }
    boolean hasProfile() { return !load().isEmpty(); }

    void clear() { prefs.edit().clear().apply(); }
}
