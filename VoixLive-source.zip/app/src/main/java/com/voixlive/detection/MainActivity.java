package com.voixlive.detection;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity implements VoiceEngine.Listener {
    private static final int MICROPHONE_REQUEST = 41;
    private static final int BG = Color.rgb(8, 11, 16);
    private static final int CARD = Color.rgb(24, 29, 39);
    private static final int TEXT = Color.rgb(239, 243, 248);
    private static final int MUTED = Color.rgb(164, 174, 191);
    private static final int GREEN = Color.rgb(89, 221, 178);
    private static final int RED = Color.rgb(255, 103, 125);

    private enum Pending { NONE, ENROLL, LISTEN }

    private VoiceEngine engine;
    private VoiceProfileStore store;
    private Pending pending = Pending.NONE;
    private boolean listening;
    private float threshold = 0.88f;
    private float attenuation = 1f;

    private TextView profileState;
    private TextView headphoneState;
    private TextView mainStatus;
    private TextView confidenceText;
    private TextView thresholdText;
    private TextView attenuationText;
    private ProgressBar confidenceBar;
    private ProgressBar levelBar;
    private Button enrollButton;
    private Button listenButton;
    private SeekBar thresholdSeek;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        store = new VoiceProfileStore(this);
        engine = new VoiceEngine(this);
        threshold = store.threshold();
        buildUi();
        refreshProfile();
        refreshHeadphones();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column(20);
        root.setPadding(dp(20), dp(22), dp(20), dp(40));
        scroll.addView(root, matchWrap());

        TextView eyebrow = label("VOIX LIVE · MODE SILENCE CIBLÉ", 13, GREEN, true);
        root.addView(eyebrow);
        TextView title = label("Le son baisse quand\nla voix cible parle", 31, TEXT, true);
        title.setLineSpacing(0, 1.06f);
        root.addView(title, margins(dp(0), dp(8), dp(0), dp(8)));
        TextView intro = label("Le téléphone reconnaît la voix enregistrée. Le flux reste continu, avec environ 1,2 s de retard — sans le lourd traitement par blocs.", 16, MUTED, false);
        intro.setLineSpacing(dp(3), 1f);
        root.addView(intro, margins(0, 0, 0, dp(22)));

        LinearLayout profileCard = card();
        profileCard.addView(section("1 · PROFIL VOCAL"));
        profileState = label("Aucun profil enregistré", 17, MUTED, false);
        profileCard.addView(profileState, margins(0, dp(8), 0, dp(14)));
        enrollButton = primaryButton("ENREGISTRER LA VOIX · 10 S", false);
        enrollButton.setOnClickListener(v -> requestAndRun(Pending.ENROLL));
        profileCard.addView(enrollButton);
        TextView tip = label("Fais parler uniquement la voix à reconnaître pendant les 10 secondes, près du téléphone et sans musique.", 14, MUTED, false);
        profileCard.addView(tip, margins(0, dp(12), 0, 0));
        root.addView(profileCard, margins(0, 0, 0, dp(14)));

        LinearLayout listeningCard = card();
        listeningCard.addView(section("2 · ÉCOUTE FILTRÉE"));
        headphoneState = label("Recherche des écouteurs…", 16, MUTED, false);
        listeningCard.addView(headphoneState, margins(0, dp(8), 0, dp(10)));

        mainStatus = label("Prêt", 24, TEXT, true);
        mainStatus.setGravity(Gravity.CENTER);
        listeningCard.addView(mainStatus, margins(0, dp(10), 0, dp(8)));
        confidenceText = label("Reconnaissance : —", 14, MUTED, false);
        listeningCard.addView(confidenceText);
        confidenceBar = progress(1000, GREEN);
        listeningCard.addView(confidenceBar, fixedHeight(dp(12), dp(8), dp(10)));
        levelBar = progress(1000, Color.rgb(107, 150, 255));
        listeningCard.addView(levelBar, fixedHeight(dp(8), 0, dp(18)));

        listenButton = primaryButton("ACTIVER L’ÉCOUTE", false);
        listenButton.setOnClickListener(v -> {
            if (listening) stopListening(); else requestAndRun(Pending.LISTEN);
        });
        listeningCard.addView(listenButton);
        root.addView(listeningCard, margins(0, 0, 0, dp(14)));

        LinearLayout settings = card();
        settings.addView(section("3 · RÉGLAGES DU TEST"));
        thresholdText = label("Reconnaissance", 15, TEXT, false);
        settings.addView(thresholdText, margins(0, dp(10), 0, 0));
        thresholdSeek = new SeekBar(this);
        thresholdSeek.setMax(220);
        thresholdSeek.setProgress(toThresholdProgress(threshold));
        thresholdSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                threshold = 0.76f + progress / 1000f;
                engine.setThreshold(threshold);
                updateThresholdLabel();
            }
        });
        settings.addView(thresholdSeek);
        TextView strictHelp = label("À gauche : reconnaît plus facilement. À droite : évite de couper sur d’autres voix.", 13, MUTED, false);
        settings.addView(strictHelp, margins(0, 0, 0, dp(16)));

        attenuationText = label("Baisse du son : 100 %", 15, TEXT, false);
        settings.addView(attenuationText);
        SeekBar attenuationSeek = new SeekBar(this);
        attenuationSeek.setMax(100);
        attenuationSeek.setProgress(100);
        attenuationSeek.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                attenuation = progress / 100f;
                engine.setAttenuation(attenuation);
                attenuationText.setText("Baisse du son : " + progress + " %");
            }
        });
        settings.addView(attenuationSeek);
        root.addView(settings, margins(0, 0, 0, dp(14)));

        LinearLayout instructions = card();
        instructions.addView(section("POUR ENTENDRE LE VRAI RÉSULTAT"));
        instructions.addView(label("1. Mets les écouteurs et désactive leur mode Transparence.\n\n2. Pose le téléphone près de toi : c’est son micro qui écoute la pièce.\n\n3. Active l’écoute, puis fais jouer un autre passage de la même voix.\n\n4. Regarde l’indicateur : il devient rouge quand la voix est reconnue.", 15, TEXT, false), margins(0, dp(10), 0, 0));
        root.addView(instructions);

        TextView version = label("Version 2.0 · détection locale · aucun son envoyé sur Internet", 12, MUTED, false);
        version.setGravity(Gravity.CENTER);
        root.addView(version, margins(0, dp(18), 0, 0));
        setContentView(scroll);
        updateThresholdLabel();
    }

    private void requestAndRun(Pending action) {
        pending = action;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            runPending();
        } else {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MICROPHONE_REQUEST);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == MICROPHONE_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            runPending();
        } else if (requestCode == MICROPHONE_REQUEST) {
            pending = Pending.NONE;
            Toast.makeText(this, "Le microphone est nécessaire pour reconnaître la voix.", Toast.LENGTH_LONG).show();
        }
    }

    private void runPending() {
        Pending action = pending;
        pending = Pending.NONE;
        if (action == Pending.ENROLL) startEnrollment();
        else if (action == Pending.LISTEN) startListening();
    }

    private void startEnrollment() {
        if (listening) stopListening();
        enrollButton.setEnabled(false);
        listenButton.setEnabled(false);
        profileState.setTextColor(GREEN);
        profileState.setText("Parle maintenant · 10 s");
        mainStatus.setText("Enregistrement…");
        engine.enroll();
    }

    private void startListening() {
        List<float[]> profile = store.load();
        if (profile.isEmpty()) {
            Toast.makeText(this, "Enregistre d’abord la voix cible pendant 10 secondes.", Toast.LENGTH_LONG).show();
            return;
        }
        refreshHeadphones();
        listening = true;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enrollButton.setEnabled(false);
        listenButton.setText("ARRÊTER L’ÉCOUTE");
        listenButton.setBackgroundColor(RED);
        mainStatus.setTextColor(GREEN);
        mainStatus.setText("Écoute active…");
        confidenceText.setText("Analyse de la première seconde…");
        engine.setAttenuation(attenuation);
        engine.listen(profile, threshold);
    }

    private void stopListening() {
        engine.stop();
        listening = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enrollButton.setEnabled(true);
        listenButton.setText("ACTIVER L’ÉCOUTE");
        listenButton.setBackgroundColor(GREEN);
        mainStatus.setTextColor(TEXT);
        mainStatus.setText("Prêt");
        confidenceText.setText("Reconnaissance : —");
        confidenceBar.setProgress(0);
        levelBar.setProgress(0);
    }

    private void refreshProfile() {
        List<float[]> profile = store.load();
        if (profile.isEmpty()) {
            profileState.setTextColor(MUTED);
            profileState.setText("Aucun profil enregistré");
            listenButton.setEnabled(false);
        } else {
            profileState.setTextColor(GREEN);
            profileState.setText("✓ Profil enregistré sur ce téléphone");
            listenButton.setEnabled(true);
            threshold = store.threshold();
            if (thresholdSeek != null) thresholdSeek.setProgress(toThresholdProgress(threshold));
        }
    }

    private void refreshHeadphones() {
        boolean found = false;
        AudioManager manager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        for (AudioDeviceInfo device : manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            int type = device.getType();
            if (type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                    type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                    type == AudioDeviceInfo.TYPE_BLE_SPEAKER ||
                    type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                    type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                    type == AudioDeviceInfo.TYPE_USB_HEADSET) {
                found = true;
                break;
            }
        }
        headphoneState.setText(found ? "🎧 Écouteurs détectés" : "⚠ Connecte des écouteurs avant le test");
        headphoneState.setTextColor(found ? GREEN : RED);
    }

    private void updateThresholdLabel() {
        String mode = threshold < 0.83f ? "large" : threshold < 0.90f ? "équilibrée" : "stricte";
        thresholdText.setText(String.format(Locale.FRANCE, "Reconnaissance : %s (%.0f %%)", mode, threshold * 100));
    }

    @Override public void onEnrollmentTick(int secondsLeft, float level) {
        profileState.setText("Parle maintenant · " + secondsLeft + " s");
        levelBar.setProgress(levelProgress(level));
    }

    @Override public void onEnrollmentComplete(List<float[]> profile, float suggestedThreshold) {
        store.save(profile, suggestedThreshold);
        threshold = suggestedThreshold;
        engine.setThreshold(threshold);
        enrollButton.setEnabled(true);
        listenButton.setEnabled(true);
        mainStatus.setTextColor(GREEN);
        mainStatus.setText("Profil prêt ✓");
        confidenceText.setText(profile.size() + " empreintes vocales mémorisées");
        refreshProfile();
        Toast.makeText(this, "Voix mémorisée. Tu peux activer l’écoute.", Toast.LENGTH_LONG).show();
    }

    @Override public void onListening(float score, float level, boolean targetDetected, long latencyMs) {
        confidenceBar.setProgress(Math.max(0, Math.min(1000, (int) (score * 1000))));
        levelBar.setProgress(levelProgress(level));
        confidenceText.setText(String.format(Locale.FRANCE, "Ressemblance : %.0f %% · retard %.1f s", score * 100, latencyMs / 1000f));
        if (targetDetected) {
            mainStatus.setTextColor(RED);
            mainStatus.setText("VOIX RECONNUE · SON BAISSÉ");
        } else {
            mainStatus.setTextColor(GREEN);
            mainStatus.setText("Ambiance transmise");
        }
    }

    @Override public void onStopped() { if (listening) stopListening(); }

    @Override public void onError(String message) {
        listening = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enrollButton.setEnabled(true);
        listenButton.setEnabled(store.hasProfile());
        listenButton.setText("ACTIVER L’ÉCOUTE");
        listenButton.setBackgroundColor(GREEN);
        mainStatus.setTextColor(RED);
        mainStatus.setText("Impossible de démarrer");
        confidenceText.setText(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override protected void onResume() { super.onResume(); if (headphoneState != null) refreshHeadphones(); }
    @Override protected void onDestroy() { engine.stop(); super.onDestroy(); }

    private LinearLayout card() {
        LinearLayout card = column(14);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(22));
        card.setBackground(bg);
        return card;
    }

    private LinearLayout column(int spacingIgnored) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private TextView section(String text) { return label(text, 14, GREEN, true); }

    private TextView label(String text, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLineSpacing(dp(2), 1f);
        return view;
    }

    private Button primaryButton(String text, boolean destructive) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(15);
        button.setTextColor(destructive ? TEXT : BG);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        button.setMinHeight(dp(58));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(destructive ? RED : GREEN);
        bg.setCornerRadius(dp(18));
        button.setBackground(bg);
        return button;
    }

    private ProgressBar progress(int max, int color) {
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(max);
        bar.setProgressTintList(android.content.res.ColorStateList.valueOf(color));
        bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(54, 62, 75)));
        return bar;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams margins(int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(left, top, right, bottom);
        return p;
    }

    private LinearLayout.LayoutParams fixedHeight(int height, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height);
        p.setMargins(0, top, 0, bottom);
        return p;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private int toThresholdProgress(float value) { return Math.max(0, Math.min(220, Math.round((value - 0.76f) * 1000))); }
    private int levelProgress(float level) { return Math.max(0, Math.min(1000, (int) (Math.sqrt(level) * 2600))); }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }
}
