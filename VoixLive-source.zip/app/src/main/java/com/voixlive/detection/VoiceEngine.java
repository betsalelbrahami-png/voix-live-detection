package com.voixlive.detection;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

final class VoiceEngine {
    interface Listener {
        void onEnrollmentTick(int secondsLeft, float level);
        void onEnrollmentComplete(List<float[]> profile, float threshold);
        void onListening(float score, float level, boolean targetDetected, long latencyMs);
        void onStopped();
        void onError(String message);
    }

    private static final int SAMPLE_RATE = MfccExtractor.SAMPLE_RATE;
    private static final int CHUNK_SAMPLES = 320;            // 20 ms
    private static final int LIVE_WINDOW_SAMPLES = 16000;    // 1 s
    private static final int DELAY_CHUNKS = 60;               // 1.2 s
    private static final int ANALYZE_EVERY_CHUNKS = 8;        // 160 ms

    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final MfccExtractor extractor = new MfccExtractor();
    private Thread worker;
    private volatile float threshold;
    private volatile float attenuation = 1.0f;

    VoiceEngine(Listener listener) { this.listener = listener; }

    boolean isRunning() { return running.get(); }
    void setThreshold(float value) { threshold = value; }
    void setAttenuation(float value) { attenuation = Math.max(0f, Math.min(1f, value)); }

    void enroll() {
        stop();
        running.set(true);
        worker = new Thread(this::runEnrollment, "voice-enrollment");
        worker.start();
    }

    void listen(List<float[]> profile, float initialThreshold) {
        stop();
        threshold = initialThreshold;
        running.set(true);
        List<float[]> safeProfile = new ArrayList<>(profile);
        worker = new Thread(() -> runListening(safeProfile), "voice-listening");
        worker.start();
    }

    void stop() {
        running.set(false);
        Thread current = worker;
        if (current != null && current != Thread.currentThread()) {
            try { current.join(450); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
        worker = null;
    }

    private AudioRecord createRecorder() {
        int minimum = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int size = Math.max(minimum, CHUNK_SAMPLES * 8);
        return new AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size);
    }

    private void runEnrollment() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        AudioRecord recorder = null;
        try {
            recorder = createRecorder();
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Le microphone n’a pas pu démarrer.");
            }
            short[] captured = new short[SAMPLE_RATE * 10];
            short[] chunk = new short[CHUNK_SAMPLES];
            int written = 0;
            int previousSecond = 11;
            recorder.startRecording();
            while (running.get() && written < captured.length) {
                int read = recorder.read(chunk, 0, Math.min(chunk.length, captured.length - written),
                        AudioRecord.READ_BLOCKING);
                if (read <= 0) continue;
                System.arraycopy(chunk, 0, captured, written, read);
                written += read;
                int secondsLeft = Math.max(0, 10 - written / SAMPLE_RATE);
                if (secondsLeft != previousSecond) {
                    previousSecond = secondsLeft;
                    float level = rms(chunk, read);
                    post(() -> listener.onEnrollmentTick(secondsLeft, level));
                }
            }
            if (!running.get()) return;
            recorder.stop();
            List<float[]> profile = extractor.profileWindows(captured);
            if (profile.size() < 5) {
                throw new IllegalStateException("La voix est trop faible. Réessaie plus près du téléphone, sans musique.");
            }
            float suggested = MfccExtractor.suggestedThreshold(profile);
            running.set(false);
            post(() -> listener.onEnrollmentComplete(profile, suggested));
        } catch (SecurityException e) {
            fail("Autorise le microphone pour enregistrer la voix.");
        } catch (Exception e) {
            fail(e.getMessage() == null ? "Erreur pendant l’enregistrement." : e.getMessage());
        } finally {
            if (recorder != null) {
                try { if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); } catch (Exception ignored) {}
                recorder.release();
            }
        }
    }

    private void runListening(List<float[]> profile) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        AudioRecord recorder = null;
        AudioTrack player = null;
        try {
            recorder = createRecorder();
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Le microphone n’a pas pu démarrer.");
            }
            int outMin = AudioTrack.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build();
            player = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build())
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(Math.max(outMin, CHUNK_SAMPLES * 16))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            if (player.getState() != AudioTrack.STATE_INITIALIZED) {
                throw new IllegalStateException("La sortie vers les écouteurs n’a pas pu démarrer.");
            }

            short[] history = new short[LIVE_WINDOW_SAMPLES];
            int historyWrite = 0;
            int historyCount = 0;
            int chunkCounter = 0;
            int positiveCount = 0;
            int releaseCount = 0;
            boolean detected = false;
            float lastScore = 0f;
            float currentGain = 1f;
            ArrayDeque<AudioChunk> delay = new ArrayDeque<>();

            recorder.startRecording();
            player.play();
            while (running.get()) {
                short[] data = new short[CHUNK_SAMPLES];
                int read = recorder.read(data, 0, data.length, AudioRecord.READ_BLOCKING);
                if (read <= 0) continue;
                if (read < data.length) data = Arrays.copyOf(data, read);

                for (short sample : data) {
                    history[historyWrite] = sample;
                    historyWrite = (historyWrite + 1) % history.length;
                    historyCount = Math.min(history.length, historyCount + 1);
                }
                AudioChunk queued = new AudioChunk(data);
                queued.duck = detected;
                delay.addLast(queued);

                chunkCounter++;
                if (historyCount == history.length && chunkCounter % ANALYZE_EVERY_CHUNKS == 0) {
                    short[] ordered = orderedHistory(history, historyWrite);
                    float[] live = extractor.liveWindow(ordered);
                    lastScore = MfccExtractor.profileScore(profile, live);
                    boolean candidate = live != null && lastScore >= threshold;
                    if (candidate) {
                        positiveCount++;
                        releaseCount = 0;
                        if (positiveCount >= 2) detected = true;
                    } else {
                        positiveCount = 0;
                        if (detected && ++releaseCount >= 4) detected = false;
                    }
                    if (detected) {
                        // The buffer represents the sound just analysed. Mark it before it reaches the ears.
                        for (AudioChunk buffered : delay) buffered.duck = true;
                    }
                    float level = rms(ordered, ordered.length);
                    boolean detectedNow = detected;
                    float scoreNow = lastScore;
                    post(() -> listener.onListening(scoreNow, level, detectedNow, 1200));
                }

                if (delay.size() > DELAY_CHUNKS) {
                    AudioChunk output = delay.removeFirst();
                    float targetGain = output.duck ? Math.max(0f, 1f - attenuation) : 1f;
                    float smoothing = targetGain < currentGain ? 0.45f : 0.10f;
                    currentGain += (targetGain - currentGain) * smoothing;
                    applyGain(output.data, currentGain);
                    player.write(output.data, 0, output.data.length, AudioTrack.WRITE_BLOCKING);
                }
            }
        } catch (SecurityException e) {
            fail("Autorise le microphone pour activer l’écoute.");
        } catch (Exception e) {
            fail(e.getMessage() == null ? "Erreur audio inattendue." : e.getMessage());
        } finally {
            if (recorder != null) {
                try { if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); } catch (Exception ignored) {}
                recorder.release();
            }
            if (player != null) {
                try { if (player.getPlayState() == AudioTrack.PLAYSTATE_PLAYING) player.stop(); } catch (Exception ignored) {}
                player.release();
            }
            boolean wasRunning = running.getAndSet(false);
            if (wasRunning) post(listener::onStopped);
        }
    }

    private void fail(String message) {
        running.set(false);
        post(() -> listener.onError(message));
    }

    private void post(Runnable runnable) { main.post(runnable); }

    private static short[] orderedHistory(short[] ring, int writeIndex) {
        short[] result = new short[ring.length];
        int tail = ring.length - writeIndex;
        System.arraycopy(ring, writeIndex, result, 0, tail);
        System.arraycopy(ring, 0, result, tail, writeIndex);
        return result;
    }

    private static float rms(short[] samples, int length) {
        double sum = 0.0;
        for (int i = 0; i < length; i++) {
            double x = samples[i] / 32768.0;
            sum += x * x;
        }
        return (float) Math.sqrt(sum / Math.max(1, length));
    }

    private static void applyGain(short[] samples, float gain) {
        for (int i = 0; i < samples.length; i++) samples[i] = (short) (samples[i] * gain);
    }

    private static final class AudioChunk {
        final short[] data;
        boolean duck;
        AudioChunk(short[] data) { this.data = data; }
    }
}
