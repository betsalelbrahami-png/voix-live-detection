package com.voixlive.detection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Small, dependency-free acoustic feature extractor.
 * It deliberately favours predictable CPU use over studio-grade analysis.
 */
final class MfccExtractor {
    static final int SAMPLE_RATE = 16000;
    static final int FEATURE_SIZE = 28;

    private static final int FRAME = 400;       // 25 ms
    private static final int HOP = 160;         // 10 ms
    private static final int FFT_SIZE = 512;
    private static final int MEL_BANDS = 24;
    private static final int MFCC_COUNT = 13;
    private static final double EPS = 1.0e-9;

    private final double[] window = new double[FRAME];
    private final int[] melLeft = new int[MEL_BANDS];
    private final int[] melCenter = new int[MEL_BANDS];
    private final int[] melRight = new int[MEL_BANDS];

    MfccExtractor() {
        for (int i = 0; i < FRAME; i++) {
            window[i] = 0.54 - 0.46 * Math.cos(2.0 * Math.PI * i / (FRAME - 1));
        }
        buildMelBank();
    }

    List<float[]> profileWindows(short[] pcm) {
        List<float[]> result = new ArrayList<>();
        int windowSamples = (int) (1.20 * SAMPLE_RATE);
        int stepSamples = (int) (0.40 * SAMPLE_RATE);
        if (pcm.length < windowSamples) return result;

        double maxRms = 0.0;
        for (int start = 0; start + windowSamples <= pcm.length; start += stepSamples) {
            maxRms = Math.max(maxRms, rms(pcm, start, windowSamples));
        }
        double minimum = Math.max(0.006, maxRms * 0.20);
        for (int start = 0; start + windowSamples <= pcm.length; start += stepSamples) {
            if (rms(pcm, start, windowSamples) >= minimum) {
                float[] f = extract(pcm, start, windowSamples);
                if (f != null) result.add(f);
            }
        }
        return result;
    }

    float[] liveWindow(short[] pcm) {
        return extract(pcm, 0, pcm.length);
    }

    private float[] extract(short[] pcm, int offset, int length) {
        if (length < FRAME) return null;
        List<double[]> frames = new ArrayList<>();
        List<Double> pitches = new ArrayList<>();
        List<Double> centroids = new ArrayList<>();
        List<Double> zcrs = new ArrayList<>();

        double segmentRms = rms(pcm, offset, length);
        double voicedFloor = Math.max(0.0035, segmentRms * 0.36);
        double[] real = new double[FFT_SIZE];
        double[] imag = new double[FFT_SIZE];

        for (int pos = offset; pos + FRAME <= offset + length; pos += HOP) {
            double frameRms = rms(pcm, pos, FRAME);
            if (frameRms < voicedFloor) continue;

            Arrays.fill(real, 0.0);
            Arrays.fill(imag, 0.0);
            double previous = pos > offset ? pcm[pos - 1] / 32768.0 : 0.0;
            int crossings = 0;
            double previousSample = pcm[pos] / 32768.0;
            for (int i = 0; i < FRAME; i++) {
                double sample = pcm[pos + i] / 32768.0;
                double emphasized = sample - 0.97 * previous;
                previous = sample;
                real[i] = emphasized * window[i];
                if (i > 0 && ((sample >= 0) != (previousSample >= 0))) crossings++;
                previousSample = sample;
            }

            fft(real, imag);
            double[] power = new double[FFT_SIZE / 2 + 1];
            double spectralSum = 0.0;
            double weighted = 0.0;
            for (int k = 0; k < power.length; k++) {
                power[k] = (real[k] * real[k] + imag[k] * imag[k]) / FFT_SIZE;
                double hz = k * (double) SAMPLE_RATE / FFT_SIZE;
                spectralSum += power[k];
                weighted += power[k] * hz;
            }

            double[] logMel = new double[MEL_BANDS];
            for (int m = 0; m < MEL_BANDS; m++) {
                double energy = 0.0;
                int left = melLeft[m], center = melCenter[m], right = melRight[m];
                for (int k = left; k < center; k++) {
                    energy += power[k] * (k - left) / Math.max(1.0, center - left);
                }
                for (int k = center; k <= right && k < power.length; k++) {
                    energy += power[k] * (right - k) / Math.max(1.0, right - center);
                }
                logMel[m] = Math.log(energy + EPS);
            }

            double[] mfcc = new double[MFCC_COUNT];
            for (int c = 0; c < MFCC_COUNT; c++) {
                double sum = 0.0;
                for (int m = 0; m < MEL_BANDS; m++) {
                    sum += logMel[m] * Math.cos(Math.PI * c * (m + 0.5) / MEL_BANDS);
                }
                mfcc[c] = sum;
            }
            frames.add(mfcc);
            centroids.add(spectralSum > EPS ? weighted / spectralSum : 0.0);
            zcrs.add(crossings / (double) FRAME);
            double pitch = estimatePitch(pcm, pos);
            if (pitch > 0.0) pitches.add(pitch);
        }

        if (frames.size() < 12) return null;
        float[] out = new float[FEATURE_SIZE];
        int outIndex = 0;
        // Coefficient 0 mostly describes loudness; exclude it so distance does not dominate identity.
        for (int c = 1; c < MFCC_COUNT; c++) {
            double mean = meanColumn(frames, c);
            out[outIndex++] = (float) (mean / 24.0);
        }
        for (int c = 1; c < MFCC_COUNT; c++) {
            double mean = meanColumn(frames, c);
            out[outIndex++] = (float) (stdColumn(frames, c, mean) / 12.0);
        }
        out[outIndex++] = (float) (mean(centroids) / 4000.0);
        out[outIndex++] = (float) (mean(zcrs) / 0.25);
        out[outIndex++] = (float) (mean(pitches) / 250.0);
        out[outIndex] = (float) (std(pitches) / 120.0);
        normalize(out);
        return out;
    }

    static float similarity(float[] a, float[] b) {
        if (a == null || b == null || a.length != b.length) return 0f;
        double dot = 0.0;
        for (int i = 0; i < a.length; i++) dot += a[i] * b[i];
        return (float) Math.max(-1.0, Math.min(1.0, dot));
    }

    static float profileScore(List<float[]> profile, float[] live) {
        if (live == null || profile.isEmpty()) return 0f;
        float best1 = -1f, best2 = -1f, best3 = -1f;
        for (float[] enrolled : profile) {
            float s = similarity(enrolled, live);
            if (s > best1) { best3 = best2; best2 = best1; best1 = s; }
            else if (s > best2) { best3 = best2; best2 = s; }
            else if (s > best3) { best3 = s; }
        }
        if (best3 >= 0f) return (best1 + best2 + best3) / 3f;
        if (best2 >= 0f) return (best1 + best2) / 2f;
        return best1;
    }

    static float suggestedThreshold(List<float[]> profile) {
        if (profile.size() < 3) return 0.88f;
        float[] nearest = new float[profile.size()];
        for (int i = 0; i < profile.size(); i++) {
            float best = -1f;
            for (int j = 0; j < profile.size(); j++) {
                if (i != j) best = Math.max(best, similarity(profile.get(i), profile.get(j)));
            }
            nearest[i] = best;
        }
        Arrays.sort(nearest);
        float p20 = nearest[Math.max(0, nearest.length / 5)];
        return Math.max(0.78f, Math.min(0.94f, p20 - 0.035f));
    }

    private void buildMelBank() {
        double lowMel = hzToMel(80.0);
        double highMel = hzToMel(7600.0);
        int[] bins = new int[MEL_BANDS + 2];
        for (int i = 0; i < bins.length; i++) {
            double mel = lowMel + (highMel - lowMel) * i / (bins.length - 1.0);
            int bin = (int) Math.floor((FFT_SIZE + 1) * melToHz(mel) / SAMPLE_RATE);
            bins[i] = Math.max(0, Math.min(FFT_SIZE / 2, bin));
        }
        for (int m = 0; m < MEL_BANDS; m++) {
            melLeft[m] = bins[m];
            melCenter[m] = Math.max(bins[m] + 1, bins[m + 1]);
            melRight[m] = Math.max(melCenter[m] + 1, bins[m + 2]);
        }
    }

    private static double estimatePitch(short[] pcm, int offset) {
        int minLag = SAMPLE_RATE / 350;
        int maxLag = SAMPLE_RATE / 70;
        double mean = 0.0;
        for (int i = 0; i < FRAME; i++) mean += pcm[offset + i];
        mean /= FRAME;
        double energy = 0.0;
        for (int i = 0; i < FRAME; i++) {
            double x = pcm[offset + i] - mean;
            energy += x * x;
        }
        if (energy < 1.0e7) return 0.0;
        double best = 0.0;
        int bestLag = 0;
        for (int lag = minLag; lag <= maxLag; lag++) {
            double corr = 0.0, e1 = 0.0, e2 = 0.0;
            for (int i = 0; i < FRAME - lag; i++) {
                double a = pcm[offset + i] - mean;
                double b = pcm[offset + i + lag] - mean;
                corr += a * b;
                e1 += a * a;
                e2 += b * b;
            }
            double normalized = corr / Math.sqrt(e1 * e2 + EPS);
            if (normalized > best) { best = normalized; bestLag = lag; }
        }
        return best >= 0.30 && bestLag > 0 ? SAMPLE_RATE / (double) bestLag : 0.0;
    }

    private static double rms(short[] pcm, int offset, int length) {
        double sum = 0.0;
        for (int i = 0; i < length; i++) {
            double x = pcm[offset + i] / 32768.0;
            sum += x * x;
        }
        return Math.sqrt(sum / Math.max(1, length));
    }

    private static double meanColumn(List<double[]> values, int column) {
        double sum = 0.0;
        for (double[] v : values) sum += v[column];
        return sum / values.size();
    }

    private static double stdColumn(List<double[]> values, int column, double mean) {
        double sum = 0.0;
        for (double[] v : values) { double d = v[column] - mean; sum += d * d; }
        return Math.sqrt(sum / values.size());
    }

    private static double mean(List<Double> values) {
        if (values.isEmpty()) return 0.0;
        double sum = 0.0;
        for (double value : values) sum += value;
        return sum / values.size();
    }

    private static double std(List<Double> values) {
        if (values.isEmpty()) return 0.0;
        double mean = mean(values), sum = 0.0;
        for (double value : values) { double d = value - mean; sum += d * d; }
        return Math.sqrt(sum / values.size());
    }

    private static void normalize(float[] values) {
        double sum = 0.0;
        for (float value : values) sum += value * value;
        double scale = 1.0 / Math.sqrt(sum + EPS);
        for (int i = 0; i < values.length; i++) values[i] *= scale;
    }

    private static double hzToMel(double hz) { return 2595.0 * Math.log10(1.0 + hz / 700.0); }
    private static double melToHz(double mel) { return 700.0 * (Math.pow(10.0, mel / 2595.0) - 1.0); }

    private static void fft(double[] real, double[] imag) {
        int n = real.length;
        for (int i = 1, j = 0; i < n; i++) {
            int bit = n >> 1;
            for (; (j & bit) != 0; bit >>= 1) j ^= bit;
            j ^= bit;
            if (i < j) {
                double tr = real[i]; real[i] = real[j]; real[j] = tr;
                double ti = imag[i]; imag[i] = imag[j]; imag[j] = ti;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double angle = -2.0 * Math.PI / len;
            double wLenR = Math.cos(angle), wLenI = Math.sin(angle);
            for (int i = 0; i < n; i += len) {
                double wr = 1.0, wi = 0.0;
                for (int j = 0; j < len / 2; j++) {
                    int u = i + j, v = i + j + len / 2;
                    double vr = real[v] * wr - imag[v] * wi;
                    double vi = real[v] * wi + imag[v] * wr;
                    real[v] = real[u] - vr; imag[v] = imag[u] - vi;
                    real[u] += vr; imag[u] += vi;
                    double nextWr = wr * wLenR - wi * wLenI;
                    wi = wr * wLenI + wi * wLenR;
                    wr = nextWr;
                }
            }
        }
    }
}
