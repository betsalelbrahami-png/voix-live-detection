# Voix Live — silence ciblé

Prototype Android local :

1. enregistrement de 10 secondes de la voix cible ;
2. création d'une petite empreinte acoustique sur le téléphone ;
3. écoute continue du micro avec un tampon fixe de 1,2 seconde ;
4. baisse progressive du flux complet lorsque la voix cible est reconnue ;
5. retour progressif du son ambiant entre ses phrases.

Cette version n'utilise plus `iter_model` en direct. Elle ne sépare pas les sons simultanés :
quand la cible parle, tout le flux est baissé. Aucun enregistrement n'est envoyé sur Internet.

## Test recommandé

- enregistrer uniquement la voix cible, sans musique ;
- utiliser un autre passage avec la même voix pour le test ;
- mettre des écouteurs et désactiver leur mode Transparence ;
- observer l'indicateur « VOIX RECONNUE » avant d'ajuster le curseur de reconnaissance.
